// pages/auth/login-presenter.js
import LoginPage from './login-page.js';
import AuthModel from '../../../models/auth-model.js';

const LoginPresenter = {
  async init(container) {
    container.innerHTML = await LoginPage.render();
    await LoginPage.afterRender(container); 
    const loginForm = container.querySelector('#loginForm');

    if (loginForm) {
      loginForm.addEventListener('submit', async (event) => {
        event.preventDefault();

        const emailInput = container.querySelector('#loginEmail');
        const passwordInput = container.querySelector('#loginPassword');

        if (!emailInput || !passwordInput) {
          alert('Error: Input fields not found.');
          return;
        }

        const email = emailInput.value;
        const password = passwordInput.value;

        if (!email || !password) {
            alert('Email dan password wajib diisi.');
            return;
        }
     
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
            alert('Format email tidak valid.');
            return;
        }

        try {
          await AuthModel.login({ email, password });
          alert('Login berhasil!');
          window.location.hash = '/dashboard'; 
        } catch (error) {
          alert('Login gagal: ' + error.message);
        }
      });
    } else {
      console.error("Login form with ID 'loginForm' not found in the container.");
    }

    const registerBtn = container.querySelector('.register-btn');
    const loginBtn = container.querySelector('.login-btn');
    const mainContainer = container.querySelector('.container');
    if (registerBtn) {
      registerBtn.addEventListener('click', () => {
        if (mainContainer) {
          mainContainer.classList.add('active');
        }
      });
    }
    if (loginBtn) {
      loginBtn.addEventListener('click', () => {
        if (mainContainer) {
          mainContainer.classList.remove('active');
        }
      });
    }
  },
};

