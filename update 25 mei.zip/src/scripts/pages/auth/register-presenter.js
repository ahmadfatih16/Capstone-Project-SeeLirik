import AuthModel from '../../../models/auth-model.js'; 

const RegisterPresenter = {
  async init(container) {
    const registerForm = container.querySelector('#registerForm');
    const loginBtn = container.querySelector('.login-btn');

    if (registerForm) {
      registerForm.addEventListener('submit', async (event) => {
        event.preventDefault();

        const username = container.querySelector('#registerUsername')?.value.trim();
        const email = container.querySelector('#registerEmail')?.value.trim();
        const password = container.querySelector('#registerPassword')?.value.trim();
        const storeName = container.querySelector('#registerStoreName')?.value.trim();
        const storeLocation = container.querySelector('#registerStoreLocation')?.value.trim();
        const storeDescription = container.querySelector('#registerStoreDescription')?.value.trim();

        if (!username || !email || !password || !storeName || !storeLocation || !storeDescription) {
          alert('Semua field wajib diisi.');
          return;
        }

        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
          alert('Format email tidak valid.');
          return;
        }

        if (password.length < 6) {
          alert('Password minimal harus 6 karakter.');
          return;
        }

        try {
          await AuthModel.register({ username, email, password, storeName, storeLocation, storeDescription });
          alert('Registrasi berhasil!');
          window.location.hash = '#/login';
        } catch (error) {
          alert('Registrasi gagal: ' + error.message);
        }
      });
    }

    if (loginBtn) {
      loginBtn.addEventListener('click', () => {
        window.location.hash = '#/login';
      });
    }
  },
};

export default RegisterPresenter;
