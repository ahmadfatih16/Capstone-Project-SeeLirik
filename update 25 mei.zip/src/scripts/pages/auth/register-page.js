import logoImage from './logo.png';
import RegisterPresenter from './register-presenter.js';
import './styles.css'; 
import 'leaflet/dist/leaflet.css';
import L from 'leaflet'; 

const RegisterPage = {
  async render() {
    return `
      <div class="container">
        <div class="form-box register">
          <form id="registerForm">
            <h1>Registrasi Akun</h1>
            <div class="input-box">
              <input type="text" placeholder="Username" id="registerUsername" required>
              <i class='bx bxs-user'></i>
            </div>
            <div class="input-box">
              <input type="email" placeholder="Email" id="registerEmail" required>
              <i class='bx bxs-envelope'></i>
            </div>
            <div class="input-box">
              <input type="password" placeholder="Password" id="registerPassword" required>
              <i class='bx bxs-lock-alt'></i>
            </div>
            <div class="input-box">
              <input type="text" placeholder="Nama Toko" id="registerStoreName" required>
              <i class='bx bxs-store'></i>
            </div>
            <div class="input-box">
              <input type="text" placeholder="Alamat Toko" id="registerStoreLocation" required>
              <i class='bx bxs-map'></i>
            </div>
            
            <div class="input-box">
              <label for="map">Pilih Lokasi Toko di Peta:</label>
              <button type="button" id="detectLocationBtn" class="btn" style="margin: 10px 0;">Gunakan Lokasi Saya</button>
              <div id="map" style="height: 300px; border-radius: 12px; margin-top: 10px;"></div>
              <div class="latlng-fields" style="margin-top: 10px;">
                <input type="text" id="latitude" placeholder="Latitude" required />
                <input type="text" id="longitude" placeholder="Longitude" required />
              </div>
            </div>

            <div class="input-box">
              <textarea placeholder="Deskripsi Toko" id="registerStoreDescription" required></textarea>
              <i class='bx bxs-comment-detail'></i>
            </div>
            
            <button type="submit" class="btn">Daftar</button>
          </form>
        </div>

        <div class="toggle-box">
          <div class="toggle-panel toggle-left">
            <img src="${logoImage}" alt="Logo" class="logo-image" />
            <h1>Welcome to SeeLirik!</h1>
            <p>Belum Mempunyai Akun?</p>
            <button class="btn register-btn">Daftar</button>
          </div>

          <div class="toggle-panel toggle-right">
            <img src="${logoImage}" alt="Logo" class="logo-image" />
            <h1>Welcome Back!</h1>
            <p>Sudah Mempunyai Akun?</p>
            <button class="btn login-btn">Masuk</button>
          </div>
        </div>
      </div>
    `;
  },

  async afterRender() {
    document.querySelector('.login-btn').addEventListener('click', () => {
      window.location.hash = '#/login';
    });

    const defaultIcon = L.icon({
      iconRetinaUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
      iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
      shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
      iconSize: [25, 41],    
      iconAnchor: [12, 41],  
      popupAnchor: [1, -34], 
      shadowSize: [41, 41]   
    });


    L.Marker.prototype.options.icon = defaultIcon;


    const map = L.map('map').setView([-7.797068, 110.370529], 13); // Yogyakarta
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '&copy; OpenStreetMap contributors',
    }).addTo(map);

    let marker; 

    marker = L.marker([-7.797068, 110.370529]).addTo(map);

    const latInput = document.getElementById('latitude');
    const lngInput = document.getElementById('longitude');

    map.on('click', function (e) {
      const { lat, lng } = e.latlng;

      if (marker) {
        marker.setLatLng(e.latlng);
      } else {
        marker = L.marker(e.latlng).addTo(map);
      }

      latInput.value = lat.toFixed(6);
      lngInput.value = lng.toFixed(6);
    });

    document.getElementById('detectLocationBtn').addEventListener('click', () => {
      if (!navigator.geolocation) {
        alert('Geolocation tidak didukung browser Anda.');
        return;
      }

      navigator.geolocation.getCurrentPosition((position) => {
        const { latitude, longitude } = position.coords;

        map.setView([latitude, longitude], 15);

        if (marker) {
          marker.setLatLng([latitude, longitude]);
        } else {
          marker = L.marker([latitude, longitude]).addTo(map);
        }

        latInput.value = latitude.toFixed(6);
        lngInput.value = longitude.toFixed(6);
      }, () => {
        alert('Gagal mendapatkan lokasi Anda.');
      });
    });

    function updateMarkerFromInput() {
      const lat = parseFloat(latInput.value);
      const lng = parseFloat(lngInput.value);

      if (!isNaN(lat) && !isNaN(lng)) {
        const latlng = [lat, lng];

        if (marker) {
          marker.setLatLng(latlng);
        } else {
          marker = L.marker(latlng).addTo(map);
        }

        map.setView(latlng, 15);
      }
    }

    latInput.addEventListener('change', updateMarkerFromInput);
    lngInput.addEventListener('change', updateMarkerFromInput);

    document.querySelector('#registerForm').addEventListener('submit', (e) => {
      e.preventDefault();

      const lat = latInput.value;
      const lng = lngInput.value;

      if (!lat || !lng) {
        alert('Silakan pilih lokasi toko Anda di peta terlebih dahulu.');
        return;
      }

      window.location.href = '#/dashboard';
    });
  }
};

export default RegisterPage;