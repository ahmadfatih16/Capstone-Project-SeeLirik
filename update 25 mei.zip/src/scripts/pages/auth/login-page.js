// pages/auth/login-page.js
import logoImage from './logo.png'; 
import './styles.css'; 

const LoginPage = {
  async render() {
    return `
      <div class="container">
          <div class="form-box login">
              <form id="loginForm">
                  <h1>Masuk</h1>
                  <div class="input-box">
                      <input type="email" placeholder="Email" id="loginEmail" required>
                      <i class='bx bxs-user'></i>
                  </div>
                  <div class="input-box">
                      <input type="password" placeholder="Password" id="loginPassword" required>
                      <i class='bx bxs-lock-alt' ></i>
                  </div>
                  <div class="remember-me">
                      <input type="checkbox" id="rememberMe" name="rememberMe">
                      <label for="rememberMe">Ingat Akun Saya</label>
                  </div>
                  <div class="forgot-link">
                      <a href="#">Lupa Password?</a>
                  </div>
                  <button type="submit" class="btn">Masuk</button>
              </form>
          </div>

          <div class="toggle-box">
              <div class="toggle-panel toggle-left">
                  <img src="${logoImage}" alt="Logo" class="logo-image" /> <h1>Welcome to SeeLirik!</h1>
                  <p>Belum Punya Akun?</p>
                  <button class="btn register-btn">Daftar</button>
              </div>

              <div class="toggle-panel toggle-right">
                  <img src="${logoImage}" alt="Logo" class="logo-image" /> <h1>Welcome Back!</h1>
                  <p>Sudah Mempunyai Akun?</p>
                  <button class="btn login-btn">Masuk</button>
              </div>
          </div>
      </div>
    `;
  },

async afterRender() {
    document.querySelector('.register-btn').addEventListener('click', () => {
      window.location.hash = '#/register';
    });

    document.querySelector('.form-box.login form').addEventListener('submit', (e) => {
      e.preventDefault();
      window.location.href = '#/dashboard';
    });

    const container = document.querySelector('.container');
    container.classList.remove('active');
  }
};

export default LoginPage;