export default class AkunPresenter {
  constructor() {
    this.elements = {};
  }

  async init() {
    this.bindElements();
    this.bindEvents();
    await this.fetchAkunData();
  }

  bindElements() {
    this.elements.namaTokoDisplay = document.getElementById('nama-toko-display');
    this.elements.deskripsiTokoDisplay = document.getElementById('deskripsi-toko-display');
    this.elements.namaTokoField = document.getElementById('nama-toko-field');
    this.elements.adminField = document.getElementById('admin-field');
    this.elements.alamatField = document.getElementById('alamat-field');
    this.elements.emailField = document.getElementById('email-field');
    this.elements.passwordField = document.getElementById('password-field');
    this.elements.editButton = document.getElementById('edit-akun');
    this.elements.loadingText = document.getElementById('akun-loading');
    this.elements.detailContainer = document.getElementById('akun-detail-container');
  }

  bindEvents() {
    if (this.elements.editButton) {
      this.elements.editButton.addEventListener('click', () => {
        alert('Fitur edit akan ditambahkan nanti.');
      });
    }
  }

  async fetchAkunData() {
    const token = localStorage.getItem('token');
    if (!token) {
      alert('Harap login terlebih dahulu!');
      window.location.hash = '#/login';
      return;
    }

    try {
      const response = await fetch('https://backend-seelirik-production.up.railway.app/me', {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${token}`
        },
      });

      const result = await response.json();
      if (!response.ok) {
        throw new Error(result.message || 'Login gagal');
      }

      const user = result.data;

      this.elements.namaTokoDisplay.innerText = user.storeName;
      this.elements.deskripsiTokoDisplay.innerText = user.storeDescription;
      this.elements.namaTokoField.innerText = user.storeName;
      this.elements.adminField.innerText = user.username;
      this.elements.alamatField.innerText = user.storeLocation;
      this.elements.emailField.innerText = user.email;
      this.elements.passwordField.innerText = user.password;

      // ✅ tampilkan konten, sembunyikan loading
      this.elements.loadingText.classList.add('hidden');
      this.elements.detailContainer.classList.remove('hidden');

    } catch (error) {
      alert(`Error: ${error.message}`);
      localStorage.removeItem('token');
      window.location.hash = '#/login';
    }
  }
}
